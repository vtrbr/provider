'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');

const PORT = Number(process.env.PORT) || 8080;
const HOST = process.env.HOST || '0.0.0.0';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

function mountWildcard(route, handler) {
  // Express 4: /v1/play/*  → req.params[0]
  app.get(route + '/*', handler);
  app.get(route, handler);
}

// ---------- Health ----------
app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'tedflix-provider',
    version: '3.0.0',
    uptime: process.uptime(),
  });
});

app.get('/', (_req, res) => {
  res.json({
    success: true,
    service: 'TEDFLIX Provider API',
    version: '3.0.0',
    routes: {
      health: '/health',
      busca: '/busca?q=',
      filmes: '/filmes',
      series: '/series',
      banner: '/banner',
      novos: '/novos',
      lancamentos: '/lancamentos',
      categorias: '/categoria/:slug',
      streaming: '/streaming/:platform/:tipo',
      play: '/v1..v5/play/*',
      video: '/v1..v5/video/*',
    },
  });
});

// ---------- Catalogos ----------
try {
  const filmes = require('./filmes');
  app.get('/filmes', filmes.handler);
} catch (e) {
  console.warn('[boot] filmes.js:', e.message);
}
try {
  const series = require('./series');
  app.get('/series', series.handler);
} catch (e) {
  console.warn('[boot] series.js:', e.message);
}

// ---------- Home sections ----------
try {
  app.get('/banner', require('./banner').handler);
} catch (e) {
  console.warn('[boot] banner:', e.message);
}
try {
  app.get('/novos', require('./novos').handler);
} catch (e) {
  console.warn('[boot] novos:', e.message);
}
try {
  const lanc = require('./lancamentos');
  app.get('/lancamentos', lanc.handler);
  app.get('/lancamento', lanc.handler);
} catch (e) {
  console.warn('[boot] lancamentos:', e.message);
}

// ---------- Busca global ----------
try {
  app.get('/busca', require('./busca').handler);
  app.get('/search', require('./busca').handler);
  app.get('/api/search', require('./busca').handler);
} catch (e) {
  console.warn('[boot] busca:', e.message);
}

// ---------- Categorias ----------
const catDir = path.join(__dirname, 'categorias');
if (fs.existsSync(catDir)) {
  for (const file of fs.readdirSync(catDir).filter((f) => f.endsWith('.js'))) {
    const slug = file.replace(/\.js$/, '');
    try {
      const mod = require(path.join(catDir, file));
      if (mod.handler) {
        app.get(`/categoria/${slug}`, mod.handler);
        app.get(`/categorias/${slug}`, mod.handler);
      }
    } catch (e) {
      console.warn(`[boot] categoria ${slug}:`, e.message);
    }
  }
  app.get('/categorias', (_req, res) => {
    const list = fs
      .readdirSync(catDir)
      .filter((f) => f.endsWith('.js'))
      .map((f) => {
        const slug = f.replace(/\.js$/, '');
        return { slug, id: slug, label: slug.replace(/-/g, ' ') };
      });
    res.json({ success: true, categories: list });
  });
}

// ---------- Streaming platforms ----------
const streamDir = path.join(__dirname, 'streaming');
if (fs.existsSync(streamDir)) {
  for (const platform of fs.readdirSync(streamDir)) {
    const dir = path.join(streamDir, platform);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const tipo of ['filmes', 'series']) {
      const file = path.join(dir, `${tipo}.js`);
      if (!fs.existsSync(file)) continue;
      try {
        const mod = require(file);
        if (mod.handler) {
          app.get(`/streaming/${platform}/${tipo}`, mod.handler);
          app.get(`/v3/${platform}/${tipo}`, mod.handler);
        }
      } catch (e) {
        console.warn(`[boot] streaming ${platform}/${tipo}:`, e.message);
      }
    }
  }
}

// ---------- Play / Video v1–v5 ----------
for (const n of [1, 2, 3, 4, 5]) {
  try {
    const play = require(`./play/v${n}`);
    mountWildcard(`/v${n}/play`, play.handler);
  } catch (e) {
    console.warn(`[boot] play/v${n}:`, e.message);
  }
  try {
    const video = require(`./video/v${n}`);
    mountWildcard(`/v${n}/video`, video.handler);
  } catch (e) {
    console.warn(`[boot] video/v${n}:`, e.message);
  }
}

// ---------- 404 ----------
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Rota não encontrada', path: req.path });
});

app.listen(PORT, HOST, () => {
  console.log(`[tedflix-provider] http://${HOST}:${PORT}  v3.0.0`);
});
