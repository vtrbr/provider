'use strict';
/** GET /v2/play/* — Megaflix ficha + watch (sem stream). */
const axios = require('axios');
const cheerio = require('cheerio');

const API = 2;
const BASE = (process.env.MEGAFLIX_URL || 'https://megaflix.live').replace(/\/+$/, '');
const PUBLIC_API = (process.env.PUBLIC_API_BASE || 'https://api.tedflix.site').replace(/\/+$/, '');
const CDN = (process.env.MEGAFLIX_CDN || 'https://topflixfilm.live').replace(/\/+$/, '');

const http = axios.create({
  timeout: Number(process.env.PROVIDER_TIMEOUT_MS) || 25000,
  headers: {
    'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    Accept: 'text/html,application/xhtml+xml,application/json,*/*;q=0.8',
    'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
    Referer: BASE + '/',
  },
  validateStatus: (s) => s >= 200 && s < 500,
});

function abs(href) {
  if (!href) return null;
  if (href.startsWith('//')) return 'https:' + href;
  if (href.startsWith('http')) return href;
  return BASE + (href.startsWith('/') ? href : '/' + href);
}

function rawFromReq(req) {
  let raw =
    (req.params && (req.params[0] || req.params.url)) ||
    (req.query && (req.query.url || req.query.u)) ||
    '';
  if (!raw && req.originalUrl) {
    const m = String(req.originalUrl).match(/\/v2\/play\/(.+?)(?:\?|$)/i);
    if (m) raw = m[1];
  }
  return decodeURIComponent(String(raw || '').trim());
}

function extractId(url) {
  const m = String(url).match(/\/(\d{3,})-[^/?#]+/i) || String(url).match(/[?&]id=(\d+)/i);
  return m ? m[1] : null;
}

function videoLink(raw) {
  return `${PUBLIC_API}/v2/video/${encodeURIComponent(String(raw))}`;
}

async function fetchJson(id, season = 1, series = 1) {
  const { data, status } = await http.get(`${BASE}/json`, {
    params: { id, version: 0, season, series, a: 'false', android: 0 },
    headers: { Accept: 'application/json', Referer: BASE + '/' },
  });
  if (status >= 400 || !data) return null;
  return data;
}

async function getDetail(pageUrl) {
  const id = extractId(pageUrl);
  const { data: html, status } = await http.get(pageUrl);
  if (status >= 400 || !html) {
    const err = new Error('Página Megaflix indisponível');
    err.status = status || 502;
    throw err;
  }
  const $ = cheerio.load(html);
  let title = ($('h1').first().text() || $('meta[property="og:title"]').attr('content') || '').trim();
  title = title.replace(/\s*[-–|].*?(megaflix|online|assistir).*$/i, '').trim() || title;
  const yearM = (html.match(/\b((?:19|20)\d{2})\b/) || [])[1];
  const poster =
    $('meta[property="og:image"]').attr('content') ||
    $('.poster img, .pmovie__poster img, img[itemprop="image"]').attr('src') ||
    null;
  const overview = ($('meta[property="og:description"]').attr('content') || '').trim();

  let json = null;
  if (id) {
    try {
      json = await fetchJson(id, 1, 1);
    } catch (_) {}
  }

  const isSeries =
    (json && String(json.video_type || '').toLowerCase() === 'series') ||
    /\/series?\//i.test(pageUrl);

  // watch sempre aponta para o resolver de vídeo (mesmo se json ainda vazio)
  const watchTarget = id ? `${BASE}/json?id=${id}` : pageUrl;
  const watch = videoLink(watchTarget);

  const out = {
    success: true,
    api: API,
    source: 'megaflix',
    type: isSeries ? 'series' : 'movie',
    id: id || null,
    title: title || (json && json.id ? `Item ${json.id}` : 'Sem título'),
    year: yearM ? parseInt(yearM, 10) : null,
    poster: abs(poster),
    overview: overview || null,
    sourceUrl: pageUrl,
    watch,
    hasVideo: !!(json && json.video_url),
  };

  // Séries: monta temporadas a partir do json tree se existir
  if (isSeries && json && json.json) {
    // estrutura variável — app pode chamar video por ep
    out.seasons = [];
  }

  return out;
}

async function handler(req, res) {
  try {
    const raw = rawFromReq(req);
    if (!raw) return res.status(400).json({ success: false, error: 'URL ausente após /v2/play/' });
    const pageUrl = /^https?:\/\//i.test(raw) ? raw : abs(raw);
    const detail = await getDetail(pageUrl);
    return res.json(detail);
  } catch (err) {
    return res.status(err.status || 500).json({ success: false, error: err.message || 'Falha Megaflix play' });
  }
}

module.exports = { handler, getDetail, API, source: 'megaflix' };
