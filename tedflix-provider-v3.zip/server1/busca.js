'use strict';

/**
 * GET /busca?q=
 * Pesquisa global — apenas MegaCine + Megaflix
 */

const axios = require('axios');
const cheerio = require('cheerio');
const NodeHttp = require('http');

const MEGACINE = (process.env.MEGACINE_URL || 'https://megacine.yachts').replace(/\/+$/, '');
const MEGAFLIX = (process.env.MEGAFLIX_URL || 'https://megaflix.live').replace(/\/+$/, '');
const PUBLIC_API = (process.env.PUBLIC_API_BASE || 'https://api.tedflix.site').replace(/\/+$/, '');
const PLAY_V1 = `${PUBLIC_API}/v1/play/`;
const PLAY_V2 = `${PUBLIC_API}/v2/play/`;

const http = axios.create({
  timeout: Number(process.env.PROVIDER_TIMEOUT_MS) || 20000,
  headers: {
    'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
    'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
  },
  validateStatus: (s) => s >= 200 && s < 500,
  httpAgent: new NodeHttp.Agent({ keepAlive: true, maxSockets: 20 }),
});

function abs(base, href) {
  if (!href) return null;
  if (href.startsWith('//')) return 'https:' + href;
  if (href.startsWith('http')) return href;
  return base + (href.startsWith('/') ? href : '/' + href);
}

function parseMegacine(html) {
  const $ = cheerio.load(html);
  const items = [];
  // busca usa .result-item > article; catálogo usa article.item
  const nodes = $('.result-item article, article.item, .search-page article');
  nodes.each((_, el) => {
    const $el = $(el);
    const $a = $el.find('.image a, .thumbnail a, a[href*="/filmes/"], a[href*="/series/"]').first();
    const href = $a.attr('href');
    if (!href) return;
    const title = (
      $el.find('.title a, .title, h3 a, h3').first().text() ||
      $el.find('img').attr('alt') ||
      ''
    ).trim();
    if (!title) return;
    const yearM = ($el.find('.meta, .year, span').text() || '').match(/\b((?:19|20)\d{2})\b/);
    let cover = $el.find('img').attr('data-src') || $el.find('img').attr('src') || null;
    if (cover && /\/w92\//.test(cover)) cover = cover.replace('/w92/', '/w342/');
    const type =
      /\/series?\//i.test(href) ||
      /tvshows|tv\b/i.test($el.find('.movies, .tvshows, span').text()) ||
      $el.hasClass('tvshows')
        ? 'series'
        : 'movie';
    items.push({
      title,
      year: yearM ? parseInt(yearM[1], 10) : null,
      cover: abs(MEGACINE, cover),
      type,
      link: PLAY_V1 + abs(MEGACINE, href),
      source: 'megacine',
      api: 'v1',
    });
  });
  return items;
}

function parseMegaflix(html) {
  const $ = cheerio.load(html);
  const items = [];
  $('.poster.grid-item, .poster').each((_, el) => {
    const $el = $(el);
    const $a = $el.find('.poster__title a, a').first();
    const href = $a.attr('href');
    if (!href) return;
    const title = ($a.find('span').first().text() || $a.text() || $el.find('img').attr('alt') || '').trim();
    if (!title) return;
    const year = ($el.find('.bslide__meta span, .year').first().text() || '').match(/\d{4}/)?.[0] || null;
    let cover = $el.find('img').attr('src') || null;
    if (cover && cover.startsWith('?')) cover = null;
    const type = /\/series?\//i.test(href) ? 'series' : 'movie';
    items.push({
      title,
      year: year ? parseInt(year, 10) : null,
      cover: abs(MEGAFLIX, cover),
      type,
      link: PLAY_V2 + abs(MEGAFLIX, href),
      source: 'megaflix',
      api: 'v2',
    });
  });
  return items;
}

async function searchAll(q) {
  const query = String(q || '').trim();
  if (query.length < 2) return { success: true, query, data: [] };

  const encoded = encodeURIComponent(query);
  const settled = await Promise.allSettled([
    http.get(`${MEGACINE}/?s=${encoded}`).then((r) => parseMegacine(r.data || '')),
    http
      .post(
        `${MEGAFLIX}/index.php?do=search`,
        `do=search&subaction=search&story=${encoded}`,
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded', Referer: MEGAFLIX + '/' } }
      )
      .then((r) => parseMegaflix(r.data || ''))
      .catch(async () => {
        const r = await http.get(`${MEGAFLIX}/?s=${encoded}`);
        return parseMegaflix(r.data || '');
      }),
  ]);

  const sources = [];
  const data = [];
  const labels = ['megacine', 'megaflix'];
  settled.forEach((s, i) => {
    if (s.status === 'fulfilled') {
      sources.push({ source: labels[i], ok: true, count: s.value.length });
      data.push(...s.value);
    } else {
      sources.push({ source: labels[i], ok: false, error: String(s.reason?.message || s.reason) });
    }
  });

  return { success: true, query, sources, data, total: data.length };
}

async function handler(req, res) {
  try {
    const q = req.query?.q || req.query?.search || req.query?.query || '';
    res.json(await searchAll(q));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { handler, searchAll };
